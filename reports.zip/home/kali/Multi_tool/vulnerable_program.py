#!/usr/bin/env python3

# This is a vulnerable program that has known security flaws
VULNERABLE_PACKAGE = "vuln_package_v1.0"

print(f"Running {VULNERABLE_PACKAGE}...")
print("Warning: This package contains known security vulnerabilities!")
